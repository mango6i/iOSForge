# My iOSForge build workspace

This clean package contains only the iOSForge build environment. It does not contain user projects, tokens, certificates, artifacts, or repository history.

1. Create a new PRIVATE repository under your own personal GitHub account.
2. Extract this ZIP and upload ALL its contents to the root of that repository, including the .github folder. Do not upload the ZIP itself.
3. Enable Actions if GitHub requests it. Confirm .github/workflows/build.yml exists.
4. Create a fine-grained token for only YOUR repository: Actions and Contents -> Read and write.
5. Open https://mango6i.github.io/iOSForge/ and enter YOUR username/repository, actual branch, and token. Check repository ownership and visibility before uploading source.

Guide: https://mango6i.github.io/iOSForge/guide.html#own-repository

The web UI uses the GitHub API directly; no personal repository is selected by default. Private repositories reduce public exposure, but do not remove risks from untrusted source, dependencies, workflow code, credentials, collaborators, or browser extensions. GitHub Actions uses your own account's quota.

iOS target: 15.0 or later. IPA defaults to unsigned; Theos outputs dylib/deb. Successful binaries are committed as real files directly under sources/Download/, with no outer ZIP or nested run folder. Native Xcode projects and Theos projects are supported. Generated projects such as XcodeGen specs require their generation step before normal project discovery; merely including project.yml is not sufficient in this version.
