from __future__ import annotations

import os
from pathlib import Path
import shutil
import tempfile

from .manifest import Manifest
from .process import BuildError, command_path, run


def _build_package(manifest: Manifest) -> Path:
    if manifest.theos_project_dir is None:
        raise BuildError("No Theos project configured")
    project_dir = manifest.theos_project_dir
    if not (project_dir / "Makefile").exists():
        raise BuildError(f"Theos Makefile not found in {project_dir}")

    theos_root = manifest.theos_root or (Path(os.environ["THEOS"]) if os.environ.get("THEOS") else None)
    if theos_root is None:
        raise BuildError("Set THEOS or configure [theos].root before building a plugin")
    if not theos_root.exists():
        raise BuildError(f"Theos root does not exist: {theos_root}")

    make = shutil.which("gmake") or command_path("make")
    before = {path: path.stat().st_mtime_ns for path in project_dir.glob("packages/*.deb")}
    run([
        make, "package", "FINALPACKAGE=1", f"THEOS={theos_root}",
        f"TARGET=iphone:clang:latest:{manifest.minimum_ios}",
        f"ARCHS={' '.join(manifest.theos_archs)}",
        f"THEOS_PACKAGE_SCHEME={'' if manifest.package_scheme == 'rootful' else 'rootless'}",
    ], cwd=project_dir)
    packages = sorted(project_dir.glob("packages/*.deb"), key=lambda path: path.stat().st_mtime)
    packages = [path for path in packages if before.get(path) != path.stat().st_mtime_ns]
    if not packages:
        raise BuildError("Theos completed but no .deb package was found in packages/")

    return packages[-1]


def build_deb(manifest: Manifest, output_dir: Path) -> list[Path]:
    package = _build_package(manifest)
    output_dir.mkdir(parents=True, exist_ok=True)
    result = output_dir / package.name
    shutil.copy2(package, result)
    return [result]


def build_plugin(manifest: Manifest, output_dir: Path) -> list[Path]:
    package = _build_package(manifest)
    return extract_dylibs(package, output_dir)


def extract_dylibs(package: Path, output_dir: Path) -> list[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    dpkg_deb = command_path("dpkg-deb")
    results: list[Path] = []
    with tempfile.TemporaryDirectory(prefix="iosforge-dylib-") as folder:
        extracted = Path(folder) / "package"
        run([dpkg_deb, "--extract", package, extracted])
        dylibs = sorted(extracted.rglob("*.dylib"))
        if not dylibs:
            raise BuildError(f"Theos package contains no .dylib: {package}")
        if len({path.name for path in dylibs}) != len(dylibs):
            raise BuildError("包内存在同名 dylib，无法安全地合并输出。请调整插件名称。")
        for dylib in dylibs:
            result = output_dir / dylib.name
            shutil.copy2(dylib, result)
            results.append(result)
    return results


def build_all(manifest: Manifest, output_dir: Path) -> list[Path]:
    package = _build_package(manifest)
    results = extract_dylibs(package, output_dir)
    result = output_dir / package.name
    shutil.copy2(package, result)
    return [result, *results]
